/**
 * ============================================================
 *  PORTFOLIO — app.js
 *  Reads PORTFOLIO_DATA from data.js and renders all sections
 * ============================================================
 */

(function () {
  'use strict';

  const D = PORTFOLIO_DATA;

  /* ── HELPERS ─────────────────────────────────────────────── */
  const el  = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
  const qs  = (s, ctx) => (ctx || document).querySelector(s);
  const qsa = (s, ctx) => [...(ctx || document).querySelectorAll(s)];

  /* ── SVG ICONS ───────────────────────────────────────────── */
  const ICONS = {
    linkedin: `<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>`,
    github:   `<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/></svg>`,
  };

  /* ── DOCUMENT TITLE ──────────────────────────────────────── */
  document.title = D.name + ' — Senior Product Manager';

  /* ── CURSOR ──────────────────────────────────────────────── */
  function initCursor() {
    if (window.matchMedia('(pointer: coarse)').matches) return;
    const dot  = el('div', 'cursor-dot');
    const ring = el('div', 'cursor-ring');
    document.body.append(dot, ring);
    let mx = 0, my = 0, rx = 0, ry = 0;
    document.addEventListener('mousemove', e => { mx = e.clientX; my = e.clientY; dot.style.left = mx+'px'; dot.style.top = my+'px'; });
    (function loop() {
      rx += (mx - rx) * 0.12;
      ry += (my - ry) * 0.12;
      ring.style.left = rx+'px';
      ring.style.top  = ry+'px';
      requestAnimationFrame(loop);
    })();
    document.querySelectorAll('a,button,.exp-card,.project-card').forEach(el => {
      el.addEventListener('mouseenter', () => { dot.style.transform = 'translate(-50%,-50%) scale(2)'; ring.style.transform = 'translate(-50%,-50%) scale(1.4)'; });
      el.addEventListener('mouseleave', () => { dot.style.transform = 'translate(-50%,-50%) scale(1)';  ring.style.transform = 'translate(-50%,-50%) scale(1)'; });
    });
  }

  /* ── NAV ─────────────────────────────────────────────────── */
  function buildNav() {
    const nav = qs('#nav');
    const inner = el('div','nav-inner');

    const logo = el('a','nav-logo');
    logo.href  = '#hero';
    const parts = D.name.split(' ');
    logo.innerHTML = parts.slice(0,-1).join(' ') + ' <span>' + parts[parts.length-1] + '.</span>';

    const links = el('nav','nav-links');
    D.navLinks.forEach(lk => {
      const a = el('a','',lk.label);
      a.href = lk.href;
      links.append(a);
    });

    const cta = el('a','nav-cta', D.ctaButton.label);
    cta.href = D.ctaButton.href;
    cta.target = '_blank';

    const burger = el('button','nav-hamburger','<span></span><span></span><span></span>');
    burger.setAttribute('aria-label','Menu');

    inner.append(logo, links, cta, burger);
    nav.append(inner);

    // mobile nav
    const mob = el('div','nav-mobile');
    D.navLinks.forEach(lk => {
      const a = el('a','',lk.label);
      a.href = lk.href;
      a.addEventListener('click', () => mob.classList.remove('open'));
      mob.append(a);
    });
    nav.append(mob);

    burger.addEventListener('click', () => mob.classList.toggle('open'));

    // scroll effect
    window.addEventListener('scroll', () => nav.classList.toggle('scrolled', window.scrollY > 40), {passive:true});
  }

  /* ── HERO ─────────────────────────────────────────────────── */
  function buildHero() {
    const section = qs('#hero');
    const h = D.hero;
    const wrap = el('div','container');
    const inner = el('div','hero-inner');

    // LEFT
    const left = el('div','hero-left');
    const tag = el('div','hero-tag', '✦ Senior Product Manager');
    const greeting = el('p','hero-greeting', h.greeting);
    const title = el('h1','hero-title');
    const nameParts = h.headline.split(' ');
    title.innerHTML = nameParts.slice(0,-1).join(' ') + ' <span class="accent">' + nameParts[nameParts.length-1] + '</span>';
    const subtitle = el('p','hero-subtitle', h.subheadline);
    const desc = el('p','hero-desc', h.description);

    const actions = el('div','hero-actions');
    const cta1 = el('a','btn-primary', D.ctaButton.label);
    cta1.href = D.ctaButton.href;
    cta1.target = '_blank';
    const cta2 = el('a','btn-outline','Download Resume');
    cta2.href = 'assets/resume.pdf';

    actions.append(cta1, cta2);

    const stats = el('div','hero-stats');
    h.stats.forEach(s => {
      const item = el('div','hero-stat');
      item.innerHTML = `<div class="hero-stat-value">${s.value}</div><div class="hero-stat-label">${s.label}</div>`;
      stats.append(item);
    });

    left.append(tag, greeting, title, subtitle, desc, actions, stats);

    // RIGHT — profile image
    const right = el('div','hero-image-wrap');
    const glow  = el('div','hero-image-glow');
    const frame = el('div','hero-image-frame');
    if (h.profileImage) {
      const img = el('img');
      img.src = h.profileImage;
      img.alt = D.name + ' profile photo';
      img.onerror = () => { frame.innerHTML = '<div class="hero-image-placeholder">👤</div>'; };
      frame.append(img);
    } else {
      frame.innerHTML = '<div class="hero-image-placeholder">👤</div>';
    }
    const badge = el('div','hero-image-badge','✦ Available for Opportunities');
    frame.append(badge);
    right.append(glow, frame);

    inner.append(left, right);
    wrap.append(inner);
    section.append(wrap);
  }

  /* ── ABOUT ─────────────────────────────────────────────────── */
  function buildAbout() {
    const section = qs('#about');
    const ab = D.about;
    const wrap = el('div','container');
    const inner = el('div','about-inner');

    // LEFT
    const left = el('div');
    const label = el('span','section-label reveal','ABOUT ME');
    const heading = el('h2','section-heading reveal reveal-delay-1');
    heading.innerHTML = 'What do I <em>bring?</em>';
    const body = el('div','about-body reveal reveal-delay-2');
    ab.body.forEach(p => { const para = el('p','',p); body.append(para); });

    const stats = el('div','about-stats reveal reveal-delay-3');
    ab.stats.forEach(s => {
      stats.innerHTML += `<div class="about-stat"><div class="about-stat-value">${s.value}</div><div class="about-stat-label">${s.label}</div></div>`;
    });

    left.append(label, heading, body, stats);

    // RIGHT
    const right = el('div','reveal reveal-delay-2');
    const elabel = el('p','expertise-heading','Core Expertise');
    const pills  = el('div','expertise-pills');
    ab.expertise.forEach(e => {
      const p = el('span','pill', e);
      pills.append(p);
    });
    right.append(elabel, pills);

    inner.append(left, right);
    wrap.append(inner);
    section.append(wrap);
  }

  /* ── EXPERIENCE ──────────────────────────────────────────── */
  function buildExperience() {
    const section = qs('#experience');
    const wrap = el('div','container');
    const label = el('span','section-label reveal','EXPERIENCE');
    const heading = el('h2','section-heading reveal reveal-delay-1');
    heading.innerHTML = 'My work <em>experience</em>';

    const list = el('div','experience-list');
    D.experience.forEach((exp, i) => {
      const card = el('div','exp-card reveal');
      card.style.transitionDelay = (i * 0.1) + 's';

      const header = el('div','exp-header');
      const meta   = el('div','exp-meta');
      meta.innerHTML = `<div class="exp-company">${exp.company}</div><div class="exp-role">${exp.role}</div><div class="exp-info"><span>📍 ${exp.location}</span><span>📅 ${exp.period}</span></div>`;
      const toggle = el('div','exp-toggle','+');
      header.append(meta, toggle);

      const bullets = el('div','exp-bullets');
      const ul = el('ul');
      exp.bullets.forEach(b => { const li = el('li','',b); ul.append(li); });
      bullets.append(ul);

      card.append(header, bullets);

      card.addEventListener('click', () => {
        const isOpen = card.classList.contains('open');
        qsa('.exp-card').forEach(c => c.classList.remove('open'));
        if (!isOpen) card.classList.add('open');
      });

      list.append(card);
    });

    wrap.append(label, heading, list);
    section.append(wrap);
  }

  /* ── PROJECTS ─────────────────────────────────────────────── */
  function buildProjects() {
    const section = qs('#projects');
    const wrap = el('div','container');
    const label = el('span','section-label reveal','SIDE PROJECTS');
    const heading = el('h2','section-heading reveal reveal-delay-1');
    heading.innerHTML = 'Things I\'ve <em>built</em>';

    const grid = el('div','projects-grid');
    D.projects.forEach((p, i) => {
      const card = el('div','project-card reveal');
      card.style.transitionDelay = (i * 0.08) + 's';

      const tags = el('div','project-tags');
      p.tags.forEach(t => { const tag = el('span','project-tag', t); tags.append(tag); });

      const title = el('h3','project-title', p.title);
      const desc  = el('p','project-desc', p.description);
      const link  = el('a','project-link', p.linkLabel);
      link.href   = p.link;
      if (p.link !== '#') link.target = '_blank';

      card.append(tags, title, desc, link);
      grid.append(card);
    });

    wrap.append(label, heading, grid);
    section.append(wrap);
  }

  /* ── SKILLS ───────────────────────────────────────────────── */
  function buildSkills() {
    const section = qs('#skills');
    const sk = D.skills;
    const wrap = el('div','container');
    const label = el('span','section-label reveal','EXPERTISE');
    const heading = el('h2','section-heading reveal reveal-delay-1');
    heading.innerHTML = sk.heading.replace('&', '&amp;').replace(/ ([^ ]+)$/, ' <em>$1</em>');

    const grid = el('div','skills-grid');
    sk.categories.forEach((cat, i) => {
      const card = el('div','skill-category reveal');
      card.style.transitionDelay = (i * 0.1) + 's';
      const lbl = el('span','skill-category-label', cat.label);
      const items = el('div','skill-items');
      cat.items.forEach(it => { const item = el('div','skill-item', it); items.append(item); });
      card.append(lbl, items);
      grid.append(card);
    });

    wrap.append(label, heading, grid);
    section.append(wrap);
  }

  /* ── TESTIMONIAL ─────────────────────────────────────────── */
  function buildTestimonial() {
    const section = qs('#testimonial');
    const t = D.testimonial;
    const wrap = el('div','container');
    const inner = el('div','testimonial-inner reveal');
    inner.innerHTML = `<span class="testimonial-quote-mark">"</span><p class="testimonial-text">${t.quote}</p><p class="testimonial-author">— ${t.author}</p>`;
    wrap.append(inner);
    section.append(wrap);
  }

  /* ── CONTACT ─────────────────────────────────────────────── */
  function buildContact() {
    const section = qs('#contact');
    const c = D.contact;
    const wrap = el('div','container');
    const inner = el('div','contact-inner');

    const heading = el('h2','contact-heading reveal');
    const words = c.heading.split(' ');
    const lastTwo = words.splice(-2).join(' ');
    heading.innerHTML = words.join(' ') + ' <em>' + lastTwo + '</em>';

    const sub = el('p','contact-sub reveal reveal-delay-1', c.subheading);

    const actions = el('div','contact-actions reveal reveal-delay-2');
    const cta = el('a','btn-primary', c.ctaLabel);
    cta.href = c.ctaHref;
    cta.target = '_blank';
    const email = el('a','btn-outline', '✉ ' + c.emailLabel);
    email.href = c.emailHref;
    actions.append(cta, email);

    const socials = el('div','social-links reveal reveal-delay-3');
    D.social.forEach(s => {
      const a = el('a','social-link');
      a.href = s.href;
      a.target = '_blank';
      a.setAttribute('aria-label', s.label);
      a.innerHTML = ICONS[s.icon] || s.label;
      socials.append(a);
    });

    inner.append(heading, sub, actions, socials);
    wrap.append(inner);
    section.append(wrap);
  }

  /* ── FOOTER ──────────────────────────────────────────────── */
  function buildFooter() {
    const footer = qs('footer');
    const wrap = el('div','container');
    const inner = el('div','footer-inner');

    const logo = el('a','footer-logo');
    logo.href = '#hero';
    const parts = D.name.split(' ');
    logo.innerHTML = parts.slice(0,-1).join(' ') + ' <span>' + parts[parts.length-1] + '.</span>';

    const copy = el('p','footer-copy', D.footer.copyright);

    const socials = el('div','social-links');
    D.social.forEach(s => {
      const a = el('a','social-link');
      a.href = s.href;
      a.target = '_blank';
      a.setAttribute('aria-label', s.label);
      a.innerHTML = ICONS[s.icon] || s.label;
      socials.append(a);
    });

    inner.append(logo, copy, socials);
    wrap.append(inner);
    footer.append(wrap);
  }

  /* ── SCROLL REVEAL ────────────────────────────────────────── */
  function initReveal() {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); obs.unobserve(e.target); } });
    }, { threshold: 0.1 });
    document.querySelectorAll('.reveal').forEach(el => obs.observe(el));
  }

  /* ── INIT ─────────────────────────────────────────────────── */
  function init() {
    buildNav();
    buildHero();
    buildAbout();
    buildExperience();
    buildProjects();
    buildSkills();
    buildTestimonial();
    buildContact();
    buildFooter();
    initReveal();
    initCursor();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
