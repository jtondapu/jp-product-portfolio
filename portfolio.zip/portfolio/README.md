# Jay Mehta — Portfolio

A clean, dark-themed personal portfolio site ready for GitHub Pages hosting.

## 📁 Structure

```
portfolio/
├── index.html              ← HTML shell (no content here)
├── assets/
│   ├── css/styles.css      ← All styles
│   ├── js/
│   │   ├── data.js         ← ✏️  EDIT THIS to update all content
│   │   └── app.js          ← Renders the site from data.js
│   ├── images/
│   │   └── profile.jpg     ← Add your profile photo here
│   └── resume.pdf          ← Add your resume PDF here (optional)
└── README.md
```

## ✏️ Updating Content

**All content lives in `assets/js/data.js`.**  
Open that single file and update:

| Key | What it controls |
|-----|-----------------|
| `name` | Your name (nav + footer logo) |
| `hero` | Headline, subtitle, stats, profile image path |
| `about` | Body paragraphs, stats, expertise pills |
| `experience` | Company, role, period, bullet points |
| `projects` | Title, tags, description, link |
| `skills.categories` | Skill groups and items |
| `testimonial` | Quote and attribution |
| `contact` | CTA text, email, links |
| `social` | LinkedIn and GitHub URLs |

## 🖼️ Adding Your Profile Photo

1. Drop your photo into `assets/images/`
2. In `data.js`, update `hero.profileImage`:
   ```js
   profileImage: "assets/images/your-photo.jpg",
   ```

## 🚀 Deploying to GitHub Pages

1. Create a new GitHub repository (e.g. `yourusername.github.io`)
2. Push all files to the `main` branch:
   ```bash
   git init
   git add .
   git commit -m "Initial portfolio"
   git remote add origin https://github.com/yourusername/yourusername.github.io.git
   git push -u origin main
   ```
3. In GitHub → Settings → Pages → Source: `Deploy from branch` → `main` → `/ (root)`
4. Your site will be live at `https://yourusername.github.io`

For a **custom repo name** (not `username.github.io`), the URL will be:  
`https://yourusername.github.io/repo-name/`

## 🎨 Customizing Colors

In `assets/css/styles.css`, edit the `:root` variables at the top:

```css
:root {
  --accent:    #c8f135;   /* ← lime green signature color */
  --bg:        #0a0a0a;   /* ← page background */
  --bg-card:   #111111;   /* ← card background */
  /* ... */
}
```
